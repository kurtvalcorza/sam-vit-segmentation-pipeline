"""Row 78 review probes for tutorials/sam_vit_segmentation_colab.ipynb (sam-vit-segmentation-pipeline @ ed74a93).

CPU-only (CUDA_VISIBLE_DEVICES=-1), local workstation env `eo-notebook-test` (torch 2.13.0+cpu, transformers 4.57.6,
numpy 2.5.3) -- NOT the notebook's pinned torch 2.14.0 and NOT a Colab/Kaggle runtime. The carried module cells
(5, 7, 9) are exec'ed from the notebook JSON exactly as the notebook defines them. The model snapshot is read
(read-only) from Kurt's checkout; the ADE20K row-group cache is a copy under ./work.

Usage: python run_probes.py <notebook.ipynb> <snapshot_dir> <out_results.json>
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import sys
import time
import traceback
import zipfile
from pathlib import Path

NB, SNAP, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
results: dict = {"environment": {}, "probes": {}}


def save():
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


def probe(name):
    def deco(fn):
        t0 = time.perf_counter()
        try:
            results["probes"][name] = {"ok": True, **fn()}
        except Exception as exc:  # noqa: BLE001
            results["probes"][name] = {"ok": False, "error": f"{type(exc).__name__}: {exc}", "tb": traceback.format_exc()[-1500:]}
        results["probes"][name]["seconds"] = round(time.perf_counter() - t0, 1)
        save()  # write-immediately
        return fn
    return deco


raw = NB.read_bytes()
nb = json.loads(raw.decode("utf-8"))
cells = nb["cells"]
src = lambda i: "".join(cells[i]["source"])  # noqa: E731


@probe("P0_static")
def _p0():
    blob = hashlib.sha1(b"blob %d\0" % len(raw) + raw).hexdigest()
    compiled, failed = 0, []
    for i, c in enumerate(cells):
        if c["cell_type"] == "code":
            try:
                compile(src(i), f"cell{i}", "exec")
                compiled += 1
            except SyntaxError as exc:
                failed.append((i, str(exc)))
    code_text = "\n".join(src(i) for i, c in enumerate(cells) if c["cell_type"] == "code")
    md_text = "\n".join(src(i) for i, c in enumerate(cells) if c["cell_type"] == "markdown")
    return {
        "git_blob": blob,
        "nbformat": [nb["nbformat"], nb["nbformat_minor"]],
        "cells": len(cells),
        "code_cells_compiled": compiled,
        "compile_failures": failed,
        "outputs_present": sum(len(c.get("outputs", [])) for c in cells if c["cell_type"] == "code"),
        "metadata_dimer": nb["metadata"].get("dimer"),
        "google_colab_imports": [i for i, c in enumerate(cells) if c["cell_type"] == "code" and "google.colab" in src(i)],
        "asserts": [(i, line.strip()) for i, c in enumerate(cells) if c["cell_type"] == "code" for line in src(i).splitlines() if line.strip().startswith("assert ")],
        "pip_install_cell": [i for i, c in enumerate(cells) if c["cell_type"] == "code" and "'pip', 'install'" in src(i)],
        "uv_used": "uv " in code_text or "'uv'" in code_text,
        "guided_markers_in_markdown": {k: (k.lower() in md_text.lower()) for k in ["How to use", "Roadmap", "Glossary", "Predict", "Checkpoint", "Sample answer", "Troubleshooting", "Infrastructure", "Expected result", "What to notice", "Look for", "<details>"]},
        "env_var_read": "DIMER_NOTEBOOK_CI_PREINSTALLED" in code_text,
    }


# --- carried modules exactly as the notebook defines them --------------------------------------------------------
ns: dict = {"__name__": "__main__"}
results["environment"]["cuda_visible_devices"] = os.environ.get("CUDA_VISIBLE_DEVICES")
for i in (5, 7, 9):
    exec(compile(src(i), f"cell{i}", "exec"), ns)  # noqa: S102
import numpy as np  # noqa: E402
import torch  # noqa: E402
import transformers  # noqa: E402
from PIL import Image  # noqa: E402

torch.set_num_threads(max(1, (os.cpu_count() or 4) // 2))
results["environment"].update({"python": sys.version.split()[0], "torch": torch.__version__, "transformers": transformers.__version__, "numpy": np.__version__, "cuda_available": torch.cuda.is_available(), "note": "local CPU workstation, not the pinned torch 2.14.0, not Colab/Kaggle"})
save()


def square_record(k, side=48):
    rng = np.random.default_rng(k)
    img = Image.fromarray(rng.integers(0, 255, (side, side, 3), dtype=np.uint8))
    m = np.zeros((side, side), bool)
    m[10:30, 12:34] = True
    return {"id": f"r{k}", "image": img, "mask": m, "point": ns["interior_point"](m), "box": ns["mask_box"](m)}


@probe("P1_byod_minimum")
def _p1():
    """Smallest BYOD size that survives the notebook's BYOD path: split_dataset then validate_dataset per split (cell 13)."""
    rows = {}
    smallest = None
    for n in list(range(8, 61)):
        recs = [square_record(k) for k in range(n)]
        try:
            splits = ns["split_dataset"](recs, seed=42)
            sizes = {k: len(v) for k, v in splits.items()}
            for name, part in splits.items():
                ns["validate_dataset"](part)
            rows[n] = {"sizes": sizes, "verdict": "ok"}
            if smallest is None:
                smallest = n
        except ValueError as exc:
            rows[n] = {"verdict": "rejected", "error": str(exc)}
    return {"stated_minimum": "at least eight images (cell 0) / 8..5,000 records (cell 1)", "smallest_n_that_passes": smallest, "n8": rows[8], "n49": rows[49], "n50": rows[50]}


@probe("P2_byod_zip8_through_cell13")
def _p2():
    """An 8-image BYOD zip (the stated minimum) through load_byod_dataset -> split_dataset -> per-split validate."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for k in range(8):
            r = square_record(k, side=64)
            b1, b2 = io.BytesIO(), io.BytesIO()
            r["image"].save(b1, "PNG")
            Image.fromarray((r["mask"] * 255).astype(np.uint8)).save(b2, "PNG")
            z.writestr(f"img{k}.png", b1.getvalue())
            z.writestr(f"img{k}_mask.png", b2.getvalue())
    p = Path("work/byod8.zip")
    p.write_bytes(buf.getvalue())
    recs = ns["load_byod_dataset"](p)
    splits = ns["split_dataset"](recs, seed=42)
    sizes = {k: len(v) for k, v in splits.items()}
    try:
        {name: ns["validate_dataset"](part) for name, part in splits.items()}
        verdict = "accepted"
        err = None
    except ValueError as exc:
        verdict, err = "rejected", str(exc)
    try:
        import google.colab  # noqa: F401
        colab = "importable"
    except ModuleNotFoundError as exc:
        colab = f"ModuleNotFoundError: {exc}"
    return {"loaded": len(recs), "split_sizes": sizes, "verdict": verdict, "error": err, "google_colab_outside_colab": colab}


# --- model-backed probes (CPU) --------------------------------------------------------------------------------
pipe = None


@probe("P3_load_model_cpu")
def _p3():
    global pipe
    pipe = ns["SAMViTSegmentationPipeline"].from_pretrained(weights_dir=SNAP, device="cpu")
    return {"device": pipe.device}


def disc_record(k, side=256, r=50):
    rng = np.random.default_rng(100 + k)
    arr = rng.integers(60, 200, (side, side, 3), dtype=np.uint8)
    yy, xx = np.ogrid[:side, :side]
    cx, cy = 90 + 10 * (k % 8), 110 + 5 * (k % 8)
    m = (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r
    arr[m] = (rng.integers(0, 255, 3)).astype(np.uint8)
    img = Image.fromarray(arr)
    return {"id": f"disc{k}", "image": img, "mask": m, "point": ns["interior_point"](m), "box": ns["mask_box"](m), "category": "disc"}


def _p4():
    """BYOD-like round objects: cell 17 asserts frozen_box IoU > centre-disk baseline unconditionally."""
    recs = [disc_record(k) for k in range(8)]
    disk = ns["centre_disk_baseline"](recs)
    box = ns["box_fill_baseline"](recs)
    frozen_box = pipe.evaluate(recs, prompt="box")
    return {"n": 8, "centre_disk_iou": round(disk["iou"], 4), "box_fill_iou": round(box["iou"], 4), "frozen_box_iou": round(frozen_box["iou"], 4),
            "cell17_assert_frozen_box_gt_disk": frozen_box["iou"] > disk["iou"]}


if os.environ.get("SKIP_P4") != "1":
    probe("P4_round_objects_cell17_assert")(_p4)


@probe("P5_rerun_never_resets")
def _p5():
    """Run adapt twice, as a learner following 'change PROMPTS/LEARNING_RATE and rerun' or 'USE_BYOD=True, re-run from Section 4' would."""
    # pyarrow is absent from the local env, so the ADE20K cache cannot be read here; the reset behaviour does not
    # depend on the data, so synthetic disc records (distinct seeds per split) stand in. Labelled as stand-ins.
    def rect_record(k):
        r = disc_record(k)
        r["id"] = f"s{k}"
        return r
    train = [rect_record(k) for k in range(20, 28)]
    val = [rect_record(k) for k in range(40, 43)]
    test = [rect_record(k) for k in range(60, 63)]
    names = set(ns["_trainable_names"](pipe._model))
    pristine = {k: v.detach().clone() for k, v in pipe._model.state_dict().items() if k in names}
    val_score = lambda: (pipe.evaluate(val, prompt="point")["iou"] + pipe.evaluate(val, prompt="box")["iou"]) / 2.0  # noqa: E731
    frozen_test = pipe.evaluate(test, prompt="point")["iou"]
    pristine_val = val_score()
    # adapt #1 without a validation split so the final epoch is kept (the stand-in discs are too easy for
    # validation selection to keep any epoch over epoch 0 -- see P5 first attempt in run.log history)
    a1 = pipe.adapt(train, None, epochs=1, lr=1e-3, prompts="mixed")
    drift1 = max(float((pipe._model.state_dict()[k] - pristine[k]).abs().max()) for k in pristine)
    after1_test = pipe.evaluate(test, prompt="point")["iou"]
    after1_val = val_score()
    # the learner reruns Section 6 (labelled 'frozen') and Section 7 with a changed control
    a2 = pipe.adapt(train, val, epochs=1, lr=1e-3, prompts="point")
    drift2 = max(float((pipe._model.state_dict()[k] - pristine[k]).abs().max()) for k in pristine)
    return {
        "data": "synthetic disc stand-ins (pyarrow absent locally)", "n_train": 8, "n_val": 3, "n_test": 3, "lr": 1e-3, "epochs": 1,
        "true_frozen_test_point_iou": round(frozen_test, 5),
        "pristine_val_score": round(pristine_val, 5),
        "adapt1_decoder_max_abs_drift": drift1,
        "section6_rerun_labelled_frozen_test_point_iou": round(after1_test, 5),
        "val_score_after_adapt1": round(after1_val, 5),
        "adapt2_epoch0": {"note": a2["history"][0].get("note"), "val_score": round(a2["history"][0]["val"]["score"], 5)},
        "adapt2_epoch0_equals_pristine": abs(a2["history"][0]["val"]["score"] - pristine_val) < 1e-9,
        "adapt2_epoch0_equals_after_adapt1": abs(a2["history"][0]["val"]["score"] - after1_val) < 1e-9,
        "decoder_drift_from_pristine_after_rerun": drift2,
        "adapter_record_after_rerun": {k: a2[k] for k in ("prompts", "epochs", "best_epoch", "lr")},
    }

save()
print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "tb"} for k, v in results["probes"].items()}, indent=1, default=str)[:6000])
